# chrome-ext-react-ts-starter
Starter for a Chrome Extention with TS 

# develop
`npm run watch` to build the extension on each source change

# build
`npm run build` to build the ts background & contentscript + popup react app 


# Targets
## Chrome
To run the extension in Chrome `npm run start:chrome`. It will start a new instance. 

### Firefox
To run the extension in Firefox `npm run start:firefox`

