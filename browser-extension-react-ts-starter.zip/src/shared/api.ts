export enum Command {
  Connect,
}